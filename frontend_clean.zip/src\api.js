const MOCK_CATALOGUE = [
  { id: 'apple', name: 'Apple', category: 'fruit', base_price: 2.5 },
  { id: 'banana', name: 'Banana', category: 'fruit', base_price: 1.8 },
  { id: 'carrot', name: 'Carrot', category: 'vegetable', base_price: 1.2 },
  { id: 'tomato', name: 'Tomato', category: 'vegetable', base_price: 1.5 }
];

export async function fetchCatalogue() {
  // Simulate network delay
  return new Promise((resolve) => {
    setTimeout(() => resolve(MOCK_CATALOGUE), 300);
  });
}

export async function fetchRecommendation(payload) {
  // Mock price calculation logic without relying on external AWS/backend service
  return new Promise((resolve) => {
    const base = MOCK_CATALOGUE.find(item => item.name === payload.commodity)?.base_price || 2.0;
    const factor = 1 + (Math.random() * 0.2 - 0.1); // +/- 10% fluctuation
    setTimeout(() => resolve({ recommended_price: Number((base * factor).toFixed(2)) }), 400);
  });
}

