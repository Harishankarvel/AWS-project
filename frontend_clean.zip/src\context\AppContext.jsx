import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_PRODUCTS, LANGUAGES } from '../data/mockData';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // Load products & stock from localStorage or default
  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('f2c_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  // Cart State: { product, quantity }
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('f2c_cart');
    return saved ? JSON.parse(saved) : [];
  });

  // Auth state: null OR { email, name, role: 'user' | 'admin' }
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('f2c_user');
    return saved ? JSON.parse(saved) : null;
  });

  // UI Modals: open auth by default if no logged in user
  const [isAuthOpen, setIsAuthOpen] = useState(() => {
    return !localStorage.getItem('f2c_user');
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAdminPortalOpen, setIsAdminPortalOpen] = useState(false);


  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    localStorage.setItem('f2c_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('f2c_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('f2c_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('f2c_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('f2c_lang', language);
  }, [language]);

  // Auth Functions
  const login = (email, password, role = 'user') => {
    const name = email.split('@')[0];
    const userObj = { email, name: name.charAt(0).toUpperCase() + name.slice(1), role };
    setUser(userObj);
    setIsAuthOpen(false);
    return userObj;
  };

  const logout = () => {
    setUser(null);
    setIsAdminPortalOpen(false);
  };

  // Cart Functions
  const addToCart = (product, quantity = 1) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.product.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        const newQty = updated[existingIndex].quantity + quantity;
        if (newQty > product.stock) {
          alert(`Sorry, only ${product.stock} ${product.unit} available in stock!`);
          return prev;
        }
        updated[existingIndex].quantity = newQty;
        return updated;
      } else {
        if (quantity > product.stock) {
          alert(`Sorry, only ${product.stock} ${product.unit} available in stock!`);
          return prev;
        }
        return [...prev, { product, quantity }];
      }
    });
    setIsCartOpen(true);
  };

  const updateCartQuantity = (productId, newQty) => {
    const prod = products.find(p => p.id === productId);
    if (prod && newQty > prod.stock) {
      alert(`Cannot add more. Only ${prod.stock} items available in stock!`);
      return;
    }
    if (newQty <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity: newQty } : item));
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const clearCart = () => setCart([]);

  // Admin Portal Functions
  const updateProductStock = (productId, newStock) => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: Math.max(0, parseInt(newStock) || 0) } : p));
  };

  const addProduct = (newProduct) => {
    const created = {
      ...newProduct,
      id: 'custom_' + Date.now(),
      price: parseFloat(newProduct.price),
      stock: parseInt(newProduct.stock),
      rating: 5.0
    };
    setProducts(prev => [created, ...prev]);
  };

  const updateProductPrice = (productId, newPrice) => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, price: parseFloat(newPrice) } : p));
  };

  const getCartTotal = () => {
    return cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  };

  const getCartCount = () => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  };

  return (
    <AppContext.Provider value={{
      products,
      cart,
      user,
      language,
      setLanguage,
      searchQuery,
      setSearchQuery,
      selectedCategory,
      setSelectedCategory,
      isAuthOpen,
      setIsAuthOpen,
      isCartOpen,
      setIsCartOpen,
      isCheckoutOpen,
      setIsCheckoutOpen,
      isAdminPortalOpen,
      setIsAdminPortalOpen,
      login,
      logout,
      addToCart,
      updateCartQuantity,
      removeFromCart,
      clearCart,
      updateProductStock,
      addProduct,
      updateProductPrice,
      getCartTotal,
      getCartCount,
      LANGUAGES
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
