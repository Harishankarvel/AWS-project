import React from 'react';
import { AppProvider } from './context/AppContext';
import Navbar from './components/Navbar';
import ProductList from './components/ProductList';
import BillingPortal from './components/BillingPortal';
import AuthModal from './components/AuthModal';
import CartDrawer from './components/CartDrawer';
import CheckoutModal from './components/CheckoutModal';
import AdminPortal from './components/AdminPortal';
import './index.css';

function App() {
  return (
    <AppProvider>
      <div className="App">
        <Navbar />
        
        <main className="main-content">
          <section className="hero-banner">
            <div className="hero-text">
              <h1>🍎 Fresh Organic Farm Produce</h1>
              <p>Directly from local farmers with AI-driven dynamic pricing & live stock tracking</p>
            </div>
          </section>

          <ProductList />
          <BillingPortal />
        </main>

        <AuthModal />
        <CartDrawer />
        <CheckoutModal />
        <AdminPortal />

        <footer className="app-footer">
          <p>© 2026 FarmFresh Market. All rights reserved. 🌿 100% Organic Certified.</p>
        </footer>
      </div>
    </AppProvider>
  );
}

export default App;
