import React from 'react';
import { useApp } from '../context/AppContext';

const Navbar = () => {
  const {
    user,
    logout,
    setIsAuthOpen,
    setIsCartOpen,
    setIsAdminPortalOpen,
    getCartCount,
    language,
    setLanguage,
    LANGUAGES,
    searchQuery,
    setSearchQuery
  } = useApp();

  return (
    <header className="navbar-container">
      <div className="navbar-top">
        <div className="brand-logo" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <span className="logo-icon">🍏</span>
          <div>
            <h2>FarmFresh Market</h2>
            <span className="sub-tagline">100% Organic & Direct from Farmers</span>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="search-bar">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            placeholder="Search 50+ fresh fruits, veggies, greens..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button className="clear-search" onClick={() => setSearchQuery('')}>✕</button>
          )}
        </div>

        <div className="nav-actions">
          {/* Language Selector */}
          <div className="language-selector">
            <span className="globe-icon">🌐</span>
            <select value={language} onChange={(e) => setLanguage(e.target.value)}>
              {LANGUAGES.map(lang => (
                <option key={lang.code} value={lang.code}>
                  {lang.flag} {lang.name}
                </option>
              ))}
            </select>
          </div>

          {/* User Auth / Admin Button */}
          {user ? (
            <div className="user-profile">
              <span className={`user-badge ${user.role}`}>
                {user.role === 'admin' ? '👑 Admin' : '👤 User'}
              </span>
              <span className="user-name">{user.name}</span>
              {user.role === 'admin' && (
                <button className="admin-portal-btn" onClick={() => setIsAdminPortalOpen(true)}>
                  ⚙️ Admin Portal
                </button>
              )}
              <button className="logout-btn" onClick={logout}>Logout</button>
            </div>
          ) : (
            <button className="auth-btn" onClick={() => setIsAuthOpen(true)}>
              🔒 Login / Sign Up
            </button>
          )}

          {/* Cart Button (hidden for Admin) */}
          {(!user || user.role !== 'admin') && (
            <button className="cart-nav-btn" onClick={() => setIsCartOpen(true)}>
              🛒 Cart
              {getCartCount() > 0 && <span className="cart-badge-count">{getCartCount()}</span>}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
