import React from 'react';
import { useApp } from '../context/AppContext';

const BillingPortal = () => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    getCartTotal,
    setIsCheckoutOpen,
    user
  } = useApp();

  if (user?.role === 'admin') return null; // Billing portal is for customer purchase

  return (
    <section className="billing-portal-container">
      <div className="billing-portal-header">
        <h2>🧾 Live Shopping Billing & Invoice Portal</h2>
        <p>Real-time itemized breakdown of added cart items & estimated tax</p>
      </div>

      <div className="billing-portal-content">
        <div className="billing-table-wrapper">
          {cart.length === 0 ? (
            <div className="billing-empty">
              <span>🛒</span>
              <p>No items added to billing yet.</p>
              <small>Click "Add to Cart" on any product above to generate live invoice items.</small>
            </div>
          ) : (
            <table className="billing-table">
              <thead>
                <tr>
                  <th>Produce Item</th>
                  <th>Unit Price</th>
                  <th>Quantity</th>
                  <th>Subtotal</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {cart.map(({ product, quantity }) => (
                  <tr key={product.id}>
                    <td className="billing-item-name">
                      <span className="billing-emoji">{product.image}</span>
                      <div>
                        <strong>{product.name}</strong>
                        <br />
                        <small className="muted-text">{product.category}</small>
                      </div>
                    </td>
                    <td>${product.price.toFixed(2)} / {product.unit}</td>
                    <td>
                      <div className="billing-qty-control">
                        <button onClick={() => updateCartQuantity(product.id, quantity - 1)}>-</button>
                        <span>{quantity}</span>
                        <button onClick={() => updateCartQuantity(product.id, quantity + 1)}>+</button>
                      </div>
                    </td>
                    <td className="subtotal-cell">${(product.price * quantity).toFixed(2)}</td>
                    <td>
                      <button className="billing-delete-btn" onClick={() => removeFromCart(product.id)}>
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Invoice Summary Box */}
        {cart.length > 0 && (
          <div className="billing-summary-card">
            <h3>Invoice Summary</h3>
            <div className="summary-line">
              <span>Items Total ({cart.reduce((a, b) => a + b.quantity, 0)} items)</span>
              <span>${getCartTotal().toFixed(2)}</span>
            </div>
            <div className="summary-line">
              <span>Estimated Organic Tax (5%)</span>
              <span>${(getCartTotal() * 0.05).toFixed(2)}</span>
            </div>
            <div className="summary-line">
              <span>Express Farm Shipping</span>
              <span className="free-tag">FREE</span>
            </div>
            <hr className="divider" />
            <div className="summary-line grand-total-line">
              <span>Grand Total</span>
              <span className="grand-total-price">
                ${(getCartTotal() * 1.05).toFixed(2)}
              </span>
            </div>

            <div className="billing-actions">
              <button className="checkout-now-btn" onClick={() => setIsCheckoutOpen(true)}>
                Proceed to Payment Gateway 💳
              </button>
              <button className="clear-cart-btn" onClick={clearCart}>
                Clear Cart
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default BillingPortal;
