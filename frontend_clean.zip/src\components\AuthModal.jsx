import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const AuthModal = () => {
  const { isAuthOpen, setIsAuthOpen, login } = useApp();
  const [isSignUp, setIsSignUp] = useState(false);
  const [role, setRole] = useState('user');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  if (!isAuthOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) return alert('Please fill in all fields');
    login(email, password, role);
  };

  const fillQuickDemo = (demoRole) => {
    if (demoRole === 'admin') {
      setEmail('admin@farm.com');
      setPassword('admin123');
      setRole('admin');
    } else {
      setEmail('user@farm.com');
      setPassword('user123');
      setRole('user');
    }
  };

  return (
    <div className="modal-backdrop" onClick={() => setIsAuthOpen(false)}>
      <div className="modal-content auth-modal" onClick={e => e.stopPropagation()}>
        <button className="close-modal" onClick={() => setIsAuthOpen(false)}>✕</button>
        
        <h2>{isSignUp ? '✨ Create an Account' : '🔑 Welcome Back'}</h2>
        <p className="modal-subtitle">
          {isSignUp ? 'Sign up to shop fresh organic produce' : 'Login to access your orders and features'}
        </p>

        {/* Quick Demo Pre-fill */}
        <div className="demo-accounts">
          <span>Quick Demo Login:</span>
          <div className="demo-buttons">
            <button type="button" onClick={() => fillQuickDemo('user')}>👤 Fill User</button>
            <button type="button" onClick={() => fillQuickDemo('admin')}>👑 Fill Admin</button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="role-selector">
            <label className={`role-tab ${role === 'user' ? 'active' : ''}`}>
              <input type="radio" value="user" checked={role === 'user'} onChange={() => setRole('user')} />
              👤 Customer Account
            </label>
            <label className={`role-tab ${role === 'admin' ? 'active' : ''}`}>
              <input type="radio" value="admin" checked={role === 'admin'} onChange={() => setRole('admin')} />
              👑 Store Admin
            </label>
          </div>

          {isSignUp && (
            <div className="form-group">
              <label>Full Name</label>
              <input 
                type="text" 
                placeholder="Enter your name"
                value={name} 
                onChange={e => setName(e.target.value)} 
                required
              />
            </div>
          )}

          <div className="form-group">
            <label>Email Address</label>
            <input 
              type="email" 
              placeholder="e.g. user@farm.com" 
              value={email} 
              onChange={e => setEmail(e.target.value)} 
              required
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input 
              type="password" 
              placeholder="••••••••" 
              value={password} 
              onChange={e => setPassword(e.target.value)} 
              required
            />
          </div>

          <button type="submit" className="primary-btn submit-btn">
            {isSignUp ? 'Create Account' : `Login as ${role === 'admin' ? 'Admin' : 'Customer'}`}
          </button>
        </form>

        <div className="auth-toggle">
          {isSignUp ? (
            <p>Already have an account? <span onClick={() => setIsSignUp(false)}>Login here</span></p>
          ) : (
            <p>Don't have an account? <span onClick={() => setIsSignUp(true)}>Sign up now</span></p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
