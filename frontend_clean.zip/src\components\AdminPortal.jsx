import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const AdminPortal = () => {
  const {
    isAdminPortalOpen,
    setIsAdminPortalOpen,
    products,
    updateProductStock,
    updateProductPrice,
    addProduct,
    user
  } = useApp();

  const [activeTab, setActiveTab] = useState('inventory'); // 'inventory' | 'add'
  const [filterText, setFilterText] = useState('');

  // New product state
  const [newProd, setNewProd] = useState({
    name: '',
    category: 'fruit',
    price: '',
    stock: '',
    unit: 'kg',
    image: '🍎'
  });

  if (!isAdminPortalOpen) return null;

  const handleAddSubmit = (e) => {
    e.preventDefault();
    if (!newProd.name || !newProd.price || !newProd.stock) return alert('Please fill in all fields');
    addProduct(newProd);
    alert(`Successfully added ${newProd.name} to inventory!`);
    setNewProd({ name: '', category: 'fruit', price: '', stock: '', unit: 'kg', image: '🍎' });
    setActiveTab('inventory');
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(filterText.toLowerCase()) ||
    p.category.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <div className="modal-backdrop" onClick={() => setIsAdminPortalOpen(false)}>
      <div className="modal-content admin-portal-modal" onClick={e => e.stopPropagation()}>
        <div className="admin-header">
          <div>
            <h2>👑 Admin Management Portal</h2>
            <span className="admin-sub">Manage inventory, stock quantities, pricing and catalog items</span>
          </div>
          <button className="close-modal" onClick={() => setIsAdminPortalOpen(false)}>✕</button>
        </div>

        <div className="admin-tabs">
          <button 
            className={`tab-btn ${activeTab === 'inventory' ? 'active' : ''}`}
            onClick={() => setActiveTab('inventory')}
          >
            📦 Inventory & Stock Manager ({products.length} Items)
          </button>
          <button 
            className={`tab-btn ${activeTab === 'add' ? 'active' : ''}`}
            onClick={() => setActiveTab('add')}
          >
            ➕ Add New Fruit / Vegetable
          </button>
        </div>

        {activeTab === 'inventory' && (
          <div className="inventory-tab">
            <div className="inventory-filter">
              <input 
                type="text" 
                placeholder="Filter stock by name or category..." 
                value={filterText}
                onChange={e => setFilterText(e.target.value)}
              />
            </div>

            <div className="stock-table-container">
              <table className="stock-table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Category</th>
                    <th>Price ($)</th>
                    <th>Available Stock Quantity</th>
                    <th>Stock Level</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map(p => (
                    <tr key={p.id}>
                      <td className="item-name-cell">
                        <span className="item-icon">{p.image}</span>
                        <strong>{p.name}</strong>
                      </td>
                      <td>
                        <span className={`cat-pill ${p.category}`}>{p.category}</span>
                      </td>
                      <td>
                        <div className="editable-input">
                          $<input 
                            type="number" 
                            step="0.10"
                            value={p.price} 
                            onChange={(e) => updateProductPrice(p.id, e.target.value)}
                          /> / {p.unit}
                        </div>
                      </td>
                      <td>
                        <div className="editable-input stock-input">
                          <input 
                            type="number" 
                            value={p.stock} 
                            onChange={(e) => updateProductStock(p.id, e.target.value)}
                          /> {p.unit}
                        </div>
                      </td>
                      <td>
                        {p.stock > 50 ? (
                          <span className="stock-badge in-stock">High ({p.stock})</span>
                        ) : p.stock > 0 ? (
                          <span className="stock-badge low-stock">Low ({p.stock})</span>
                        ) : (
                          <span className="stock-badge out-stock">Out of Stock</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'add' && (
          <form className="add-product-form" onSubmit={handleAddSubmit}>
            <h3>➕ Add New Produce Item</h3>
            <p>Fill out the form below to publish a new fruit or vegetable item</p>

            <div className="form-grid">
              <div className="form-group">
                <label>Item Name</label>
                <input 
                  type="text" 
                  placeholder="e.g. Fresh Mangosteen" 
                  value={newProd.name} 
                  onChange={e => setNewProd({ ...newProd, name: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Category</label>
                <select 
                  value={newProd.category} 
                  onChange={e => setNewProd({ ...newProd, category: e.target.value })}
                >
                  <option value="fruit">Fruit 🍎</option>
                  <option value="vegetable">Vegetable 🥦</option>
                </select>
              </div>

              <div className="form-group">
                <label>Price ($ per unit)</label>
                <input 
                  type="number" 
                  step="0.01" 
                  placeholder="e.g. 3.50" 
                  value={newProd.price} 
                  onChange={e => setNewProd({ ...newProd, price: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Initial Stock Quantity</label>
                <input 
                  type="number" 
                  placeholder="e.g. 100" 
                  value={newProd.stock} 
                  onChange={e => setNewProd({ ...newProd, stock: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Unit of Measurement</label>
                <select 
                  value={newProd.unit} 
                  onChange={e => setNewProd({ ...newProd, unit: e.target.value })}
                >
                  <option value="kg">Per kg</option>
                  <option value="dozen">Per dozen</option>
                  <option value="pc">Per piece</option>
                  <option value="pack">Per pack</option>
                  <option value="box">Per box</option>
                  <option value="bunch">Per bunch</option>
                </select>
              </div>

              <div className="form-group">
                <label>Emoji / Icon</label>
                <input 
                  type="text" 
                  placeholder="e.g. 🍉" 
                  value={newProd.image} 
                  onChange={e => setNewProd({ ...newProd, image: e.target.value })}
                />
              </div>
            </div>

            <button type="submit" className="primary-btn submit-btn">
              Publish New Item to Catalog 🚀
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default AdminPortal;
