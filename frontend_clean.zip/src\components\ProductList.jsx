import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { fetchRecommendation } from '../api';

const ProductList = () => {
  const {
    products,
    searchQuery,
    selectedCategory,
    setSelectedCategory,
    addToCart,
    user
  } = useApp();

  const [aiRecommendations, setAiRecommendations] = useState({});
  const [loadingAi, setLoadingAi] = useState({});

  // Filter products by search query and category
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleGetAiRecommendation = async (product) => {
    setLoadingAi(prev => ({ ...prev, [product.id]: true }));
    try {
      const payload = { commodity: product.name, district: "North", arrival_qty: 100, cpi_inflation_index: 105, fuel_price_index: 75, seasonality: 1.0 };
      const res = await fetchRecommendation(payload);
      setAiRecommendations(prev => ({ ...prev, [product.id]: res.recommended_price }));
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAi(prev => ({ ...prev, [product.id]: false }));
    }
  };

  return (
    <div className="catalog-section">
      {/* Category Pills & Controls */}
      <div className="catalog-header-bar">
        <div className="category-pills">
          <button 
            className={`pill ${selectedCategory === 'all' ? 'active' : ''}`}
            onClick={() => setSelectedCategory('all')}
          >
            🌟 All Items ({products.length})
          </button>
          <button 
            className={`pill ${selectedCategory === 'fruit' ? 'active' : ''}`}
            onClick={() => setSelectedCategory('fruit')}
          >
            🍎 Fresh Fruits ({products.filter(p => p.category === 'fruit').length})
          </button>
          <button 
            className={`pill ${selectedCategory === 'vegetable' ? 'active' : ''}`}
            onClick={() => setSelectedCategory('vegetable')}
          >
            🥦 Vegetables ({products.filter(p => p.category === 'vegetable').length})
          </button>
        </div>

        <span className="results-count">
          Showing {filteredProducts.length} produce items
        </span>
      </div>

      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="no-products">
          <span className="no-icon">🔍</span>
          <h3>No items found</h3>
          <p>Try searching for another fruit or vegetable</p>
        </div>
      ) : (
        <div className="product-grid">
          {filteredProducts.map(product => {
            const isOutOfStock = product.stock <= 0;
            const isLowStock = product.stock > 0 && product.stock <= 20;

            return (
              <div key={product.id} className={`product-card ${isOutOfStock ? 'out-of-stock-card' : ''}`}>
                <div className="card-top-badges">
                  <span className="rating-badge">⭐ {product.rating}</span>
                  {isOutOfStock ? (
                    <span className="stock-badge out-stock">Out of Stock</span>
                  ) : isLowStock ? (
                    <span className="stock-badge low-stock">Only {product.stock} left</span>
                  ) : (
                    <span className="stock-badge in-stock">{product.stock} in stock</span>
                  )}
                </div>

                <div className="product-image-box">
                  <span className="product-emoji">{product.image}</span>
                </div>

                <div className="product-info">
                  <h3>{product.name}</h3>
                  <span className="product-unit">Price per {product.unit}</span>

                  <div className="price-row">
                    <span className="current-price">${product.price.toFixed(2)}</span>
                    {aiRecommendations[product.id] && (
                      <span className="ai-rec-price">
                        AI Recommended: <strong>${aiRecommendations[product.id].toFixed(2)}</strong>
                      </span>
                    )}
                  </div>

                  {/* AI Smart Pricing Recommendation */}
                  <button 
                    className="ai-recommend-btn"
                    onClick={() => handleGetAiRecommendation(product)}
                    disabled={loadingAi[product.id]}
                  >
                    {loadingAi[product.id] ? 'Analyzing Market...' : '🤖 AI Recommended Price'}
                  </button>

                  {/* Add to Cart Button (hidden for Admin) */}
                  {user?.role === 'admin' ? (
                    <div className="admin-item-notice">
                      ⚙️ Admin View: Stock {product.stock} {product.unit}
                    </div>
                  ) : (
                    <button 
                      className="add-to-cart-btn"
                      onClick={() => addToCart(product, 1)}
                      disabled={isOutOfStock}
                    >
                      {isOutOfStock ? 'Out of Stock' : '🛒 Add to Cart'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ProductList;
